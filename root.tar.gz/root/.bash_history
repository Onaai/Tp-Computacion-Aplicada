history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
clear
ls /dev/cdrom
mkdir -p /mnt/cdrom
mount /dev/cdrom /mnt/cdrom
apt install build-essential dkms linux-headers-$(uname -r)
reboot
mount /dev/cdrom /mnt/cdrom
ls /mnt/cdrom
sh /mnt/cdrom/VBoxLinuxAdditions.run
reboot
systemctl status vboxadd-service
clear
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
ls /root/.ssh/
ls /root/.ssh/
ls/var/www/html/
ls /var/www/html/
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
ls /var/www/html/
apt-get install mariadb-server -y
systemctl start mariadb
systemctl enable mariadb
mysql -u root < /root/Material_Adicional_TPVMCA/db.sql
mysql -u root -e "SHOW DATABASES"
ip a
ip route
nano /etc/network/interfaces
systemctl restart networking
ip a
poweroff
tail -5 /etc/fstab
sed -i '/UUID= \/www_dir/d' /etc/fstab
sed -i '/UUID= \/backup_dir/d' /etc/fstab
echo "$(blkid -s UUID -o value /dev/sdc1 | xargs -I{} echo 'UUID={}  /www_dir  ext4 defaults 0  2')" >> /etc/fstab
echo "$(blkid -s UUID -o value /dev/sdc2 | xargs -I{} echo 'UUID={}  /backup_dir  ext4 defaults 0  2')" >> /etc/fstab
tail -3 /etc/fstab
mount -a
systemctl reboot
